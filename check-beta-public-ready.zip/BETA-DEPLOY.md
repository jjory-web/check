# 검사기 베타 공개 배포 안내

이 압축파일은 `check-beta` 테스트 저장소용입니다. 미래엔 사전에서 옮겨 온 199개 설명 원문을 포함한 `mirae-spacing-rules.json`은 제외했습니다. 소수 예문 기반의 문맥 검토 제안은 코드에 남아 있습니다. 공개 사이트에 게시할 권한과 실제 규칙·문맥 판단의 정확도는 별도로 확인해야 합니다.

1. GitHub에 새 공개 저장소 `check-beta` 생성. 기존 `check`는 그대로 둡니다.
2. 이 ZIP을 풀어 `node_modules`를 제외한 파일과 폴더를 **저장소 루트**에 업로드. `.github/workflows/deploy.yml`까지 올려야 하므로 숨김 파일 표시 확인.
3. GitHub 저장소 Settings > Pages > Build and deployment > Source를 **GitHub Actions**로 설정.
4. Actions의 `Deploy GitHub Pages` 작업이 완료되면 `https://jjory-web.github.io/check-beta/`에 접속.
5. 배포가 실패하면 Actions 로그를 확인. 전체 브라우저 테스트는 배포 전 별도 검증이 필요합니다.

## 로컬 설치
Node.js 22+ 설치 후 이 폴더에서 `npm ci`, `npm run dev` 실행. `index.html` 더블클릭으로는 실행하지 않습니다.
