@echo off
rem Restart the dev server: stop whatever listens on port 5173, then run "npm run dev".
cd /d "%~dp0"
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":5173" ^| findstr "LISTENING"') do taskkill /PID %%p /F >nul 2>&1
if exist "node_modules\.vite" rmdir /s /q "node_modules\.vite"
call npm.cmd run dev
pause
